ADELAN - بسته منبع اندروید برای ساخت APK

این بسته شامل پروژه Android است. فایل gradlew داخل بسته وجود ندارد؛ بنابراین Workflow مخزن باید Gradle را روی runner نصب کند و دستور gradle assembleDebug را اجرا کند.

ساختار اصلی:
- settings.gradle
- build.gradle
- gradle.properties
- app/build.gradle
- app/src/main/...

نکته: این بسته منبع پروژه است و APK آماده نصب نیست.
